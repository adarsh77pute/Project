package com.notes.drivers;

import com.notes.config.ConfigReader;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

import java.time.Duration;

/**
 * Thread-safe WebDriver factory.
 *
 * Each test thread (TestNG parallel="methods") gets its own driver instance
 * stored in a ThreadLocal. Tests should never `new` a driver themselves.
 *
 * Lifecycle:
 *   - BaseUITest @BeforeMethod -> DriverFactory.initDriver()
 *   - tests use DriverFactory.getDriver()
 *   - BaseUITest @AfterMethod  -> DriverFactory.quitDriver()
 */
public final class DriverFactory {

    private static final Logger log = LogManager.getLogger(DriverFactory.class);
    private static final ThreadLocal<WebDriver> DRIVER = new ThreadLocal<>();

    private DriverFactory() {}

    public static WebDriver getDriver() {
        WebDriver d = DRIVER.get();
        if (d == null) {
            throw new IllegalStateException(
                    "Driver not initialised for thread " + Thread.currentThread().getName()
                            + ". Did you forget to call initDriver()?");
        }
        return d;
    }

    public static void initDriver() {
        if (DRIVER.get() != null) {
            log.warn("Driver already initialised on thread {}", Thread.currentThread().getName());
            return;
        }
        String browser = ConfigReader.get("browser", "chrome").toLowerCase();
        boolean headless = ConfigReader.getBoolean("headless", false);
        WebDriver driver = create(browser, headless);

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(
                Duration.ofSeconds(ConfigReader.getInt("implicit.wait.seconds", 0)));
        driver.manage().timeouts().pageLoadTimeout(
                Duration.ofSeconds(ConfigReader.getInt("page.load.timeout.seconds", 30)));

        DRIVER.set(driver);
        log.info("Driver [{}] initialised on thread [{}] | headless={}",
                browser, Thread.currentThread().getName(), headless);
    }

    public static void quitDriver() {
        WebDriver d = DRIVER.get();
        if (d != null) {
            try {
                d.quit();
            } catch (Exception e) {
                log.warn("Driver quit threw: {}", e.getMessage());
            } finally {
                DRIVER.remove();
                log.info("Driver quit on thread [{}]", Thread.currentThread().getName());
            }
        }
    }

    private static WebDriver create(String browser, boolean headless) {
        return switch (browser) {
            case "firefox" -> {
                WebDriverManager.firefoxdriver().setup();
                FirefoxOptions ff = new FirefoxOptions();
                if (headless) ff.addArguments("-headless");
                yield new FirefoxDriver(ff);
            }
            case "edge" -> {
                WebDriverManager.edgedriver().setup();
                EdgeOptions edge = new EdgeOptions();
                if (headless) edge.addArguments("--headless=new");
                yield new EdgeDriver(edge);
            }
            case "chrome" -> {
                WebDriverManager.chromedriver().setup();
                ChromeOptions chrome = new ChromeOptions();
                chrome.addArguments("--remote-allow-origins=*");
                chrome.addArguments("--disable-notifications");
                chrome.addArguments("--disable-popup-blocking");
                chrome.addArguments("--no-sandbox");
                chrome.addArguments("--disable-dev-shm-usage");
                if (headless) {
                    chrome.addArguments("--headless=new");
                    chrome.addArguments("--window-size=1920,1080");
                }
                yield new ChromeDriver(chrome);
            }
            default -> throw new IllegalArgumentException("Unsupported browser: " + browser);
        };
    }
}
