package com.notes.tests.api;

import com.notes.api.UserApiService;
import com.notes.api.models.UserDTO;
import com.notes.base.BaseAPITest;
import com.notes.utils.TestDataFactory;
import io.qameta.allure.*;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

@Epic("Notes App")
@Feature("API - Users")
public class UserApiTests extends BaseAPITest {

    private final UserApiService userApi = new UserApiService();

    @Test(description = "Register a new user via API — 201 with id+email back",
            groups = {"smoke", "api", "regression"})
    @Severity(SeverityLevel.BLOCKER)
    public void registerNewUser() {
        UserDTO u = new UserDTO(
                TestDataFactory.uniqueUserName(),
                TestDataFactory.uniqueEmail(),
                TestDataFactory.uniquePassword());

        Response r = userApi.register(u);

        r.then()
                .statusCode(201)
                .body("success", org.hamcrest.Matchers.equalTo(true))
                .body("data.email", org.hamcrest.Matchers.equalTo(u.getEmail()))
                .body("data.id", org.hamcrest.Matchers.notNullValue())
                .time(org.hamcrest.Matchers.lessThan(2000L));
    }

    @Test(description = "TS-01 / FR-01: Login with valid creds returns token",
            groups = {"smoke", "api", "regression"})
    @Severity(SeverityLevel.BLOCKER)
    public void loginReturnsToken_FR01() {
        UserDTO u = new UserDTO(
                TestDataFactory.uniqueUserName(),
                TestDataFactory.uniqueEmail(),
                TestDataFactory.uniquePassword());
        userApi.register(u).then().statusCode(201);

        String token = userApi.loginAndGetToken(u.getEmail(), u.getPassword());
        Assert.assertNotNull(token, "Token should be present after login.");
        Assert.assertFalse(token.isBlank(), "Token should be non-empty.");
    }
}
