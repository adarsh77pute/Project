package com.notes.utils;

import com.notes.config.ConfigReader;
import com.notes.drivers.DriverFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

/**
 * Custom waits — explicit + JS-based.
 * We avoid PageFactory entirely, per framework rules in the capstone spec.
 */
public final class WaitUtils {

    private static final Logger log = LogManager.getLogger(WaitUtils.class);
    private static final int DEFAULT_TIMEOUT =
            ConfigReader.getInt("explicit.wait.seconds", 15);

    private WaitUtils() {}

    private static WebDriverWait wait(int seconds) {
        return new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(seconds));
    }

    public static WebElement waitForVisible(By locator) {
        return waitForVisible(locator, DEFAULT_TIMEOUT);
    }

    public static WebElement waitForVisible(By locator, int seconds) {
        return wait(seconds).until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    public static WebElement waitForClickable(By locator) {
        return waitForClickable(locator, DEFAULT_TIMEOUT);
    }

    public static WebElement waitForClickable(By locator, int seconds) {
        return wait(seconds).until(ExpectedConditions.elementToBeClickable(locator));
    }

    public static boolean waitForInvisible(By locator) {
        return wait(DEFAULT_TIMEOUT).until(ExpectedConditions.invisibilityOfElementLocated(locator));
    }

    public static void waitForUrlContains(String fragment) {
        wait(DEFAULT_TIMEOUT).until(ExpectedConditions.urlContains(fragment));
    }

    public static void waitForDomReady() {
        wait(DEFAULT_TIMEOUT).until((ExpectedCondition<Boolean>) drv -> {
            assert drv != null;
            return ((JavascriptExecutor) drv)
                    .executeScript("return document.readyState").equals("complete");
        });
    }

    /** Wait until JS reports no pending jQuery or fetch requests (best-effort). */
    public static void waitForAjax() {
        try {
            wait(DEFAULT_TIMEOUT).until((ExpectedCondition<Boolean>) drv -> {
                JavascriptExecutor js = (JavascriptExecutor) drv;
                Object jqDone = js.executeScript(
                        "return (typeof jQuery === 'undefined') ? true : jQuery.active === 0");
                return Boolean.TRUE.equals(jqDone);
            });
        } catch (Exception e) {
            log.debug("AJAX wait skipped: {}", e.getMessage());
        }
    }

    public static void sleep(long millis) {
        try { Thread.sleep(millis); } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
    }
}
