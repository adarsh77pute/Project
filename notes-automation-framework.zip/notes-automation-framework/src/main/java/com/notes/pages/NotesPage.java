package com.notes.pages;

import com.notes.utils.WaitUtils;
import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.Objects;
import java.util.Optional;

/**
 * Notes dashboard.
 * Note: locators below are placeholders for the standard ExpandTesting layout;
 * if the live DOM differs, only the By constants need updating.
 */
public class NotesPage extends BasePage {

    private final By addNoteButton      = By.xpath("//button[normalize-space()='+ Add Note']");
    private final By categorySelect     = By.id("category");
    private final By titleInput         = By.id("title");
    private final By descriptionInput   = By.id("description");
    private final By createButton       = By.xpath("//button[normalize-space()='Create']");

    private final By userProfileBtn     = By.id("user-menu");
    private final By logoutLink         = By.xpath("//a[contains(.,'Logout')]");

    private final By noteCards          = By.cssSelector("[data-testid='note-card']");
    private final By noteTitleInCard    = By.cssSelector("[data-testid='note-card-title']");
    private final By noteCategoryInCard = By.cssSelector("[data-testid='note-card-category']");
    private final By noteDescInCard     = By.cssSelector("[data-testid='note-card-description']");

    public boolean isOnDashboard() { return isDisplayed(addNoteButton); }

    @Step("Open 'Add Note' form")
    public NotesPage openAddNoteForm() {
        click(addNoteButton);
        WaitUtils.waitForVisible(titleInput);
        return this;
    }

    @Step("Create note | category={category}, title={title}")
    public NotesPage createNote(String category, String title, String description) {
        openAddNoteForm();
        selectByVisibleText(categorySelect, category);
        type(titleInput, title);
        type(descriptionInput, description);
        click(createButton);
        WaitUtils.waitForDomReady();
        return this;
    }

    @Step("Check if note '{title}' is visible")
    public boolean isNoteVisible(String title) {
        return findAll(noteCards).stream()
                .map(card -> card.findElement(noteTitleInCard).getText().trim())
                .anyMatch(t -> t.equalsIgnoreCase(title));
    }

    public Optional<NoteCardData> findNote(String title) {
        for (WebElement card : findAll(noteCards)) {
            String cardTitle = card.findElement(noteTitleInCard).getText().trim();
            if (cardTitle.equalsIgnoreCase(title)) {
                return Optional.of(new NoteCardData(
                        card.findElement(noteCategoryInCard).getText().trim(),
                        cardTitle,
                        card.findElement(noteDescInCard).getText().trim()
                ));
            }
        }
        return Optional.empty();
    }

    public int countVisibleNotes() { return findAll(noteCards).size(); }

    @Step("Logout")
    public LoginPage logout() {
        click(userProfileBtn);
        click(logoutLink);
        return new LoginPage();
    }

    /** DTO for UI <-> API field comparison. */
    public record NoteCardData(String category, String title, String description) {
        public boolean matches(String apiCategory, String apiTitle, String apiDescription) {
            return Objects.equals(category.toLowerCase(), apiCategory.toLowerCase())
                    && Objects.equals(title, apiTitle)
                    && Objects.equals(description, apiDescription);
        }
    }
}
