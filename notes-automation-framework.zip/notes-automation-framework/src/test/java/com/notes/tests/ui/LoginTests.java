package com.notes.tests.ui;

import com.notes.api.UserApiService;
import com.notes.api.models.UserDTO;
import com.notes.base.BaseUITest;
import com.notes.pages.LoginPage;
import com.notes.pages.NotesPage;
import com.notes.utils.TestDataFactory;
import io.qameta.allure.*;
import org.testng.Assert;
import org.testng.annotations.Test;

@Epic("Notes App")
@Feature("UI - Login")
public class LoginTests extends BaseUITest {

    private final UserApiService userApi = new UserApiService();

    @Test(description = "TS-01 / FR-01: Valid user can log in via UI",
            groups = {"smoke", "ui", "regression"})
    @Story("Valid user login")
    @Severity(SeverityLevel.BLOCKER)
    public void validUserCanLogin_FR01() {
        // Use the API as a fixture to create a fresh user so the UI test is hermetic
        String email = TestDataFactory.uniqueEmail();
        String password = TestDataFactory.uniquePassword();
        String name = TestDataFactory.uniqueUserName();
        userApi.register(new UserDTO(name, email, password))
                .then().statusCode(201);

        NotesPage notes = new LoginPage().loginAs(email, password);

        Assert.assertTrue(notes.isOnDashboard(),
                "After login, the Notes dashboard should be visible.");
    }

    @Test(description = "TS-02 / FR-01,FR-09: Login fails with invalid credentials",
            groups = {"ui", "regression", "negative"})
    @Story("Invalid credentials login")
    @Severity(SeverityLevel.CRITICAL)
    public void invalidCredentialsAreRejected_FR01_FR09() {
        LoginPage login = new LoginPage()
                .loginExpectingFailure("nobody@nowhere.io", "WrongPass123!");

        Assert.assertTrue(login.isOnLoginPage(),
                "User should remain on login page after invalid attempt.");
        Assert.assertFalse(login.getErrorMessage().isBlank(),
                "An error message should be displayed.");
    }
}
