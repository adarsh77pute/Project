package com.notes.tests.e2e;

import com.notes.api.NotesApiService;
import com.notes.api.UserApiService;
import com.notes.api.models.UserDTO;
import com.notes.base.BaseUITest;
import com.notes.config.ConfigReader;
import com.notes.pages.LoginPage;
import com.notes.pages.NotesPage;
import com.notes.utils.ExcelReader;
import com.notes.utils.TestDataFactory;
import io.qameta.allure.*;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;

/**
 * TC-E2E-01 / FR-05: A note created via UI must appear in the
 * GET /notes API response, with all fields matching exactly.
 *
 * Data: TestData.xlsx :: E2EData :: rows where TCID = TC-E2E-01.
 */
@Epic("Notes App")
@Feature("Hybrid E2E - UI -> API sync")
public class UiToApiSyncTests extends BaseUITest {

    private final UserApiService userApi   = new UserApiService();
    private final NotesApiService notesApi = new NotesApiService();

    @BeforeClass
    public void initApi() {
        RestAssured.baseURI = ConfigReader.get("api.base.url");
    }

    @DataProvider(name = "uiToApiData")
    public Object[][] uiToApiData() {
        List<Map<String, String>> all = ExcelReader.readSheet("E2EData");
        return all.stream()
                .filter(r -> "TC-E2E-01".equals(r.get("TCID")))
                .map(r -> new Object[]{r})
                .toArray(Object[][]::new);
    }

    @Test(dataProvider = "uiToApiData",
            description = "TC-E2E-01 / FR-05 - UI created note appears in API",
            groups = {"e2e", "regression", "smoke"})
    @Story("UI -> API data consistency")
    @Severity(SeverityLevel.BLOCKER)
    public void uiCreatedNoteIsVisibleInApi_FR05(Map<String, String> row) {
        String tcid     = row.get("TCID");
        String category = row.get("Category");
        String title    = row.get("Title");
        String desc     = row.get("NoteDescription");

        Allure.parameter("TCID", tcid);
        Allure.parameter("Description", row.get("Description"));

        // --- 1. Register fresh user via API ---
        UserDTO user = new UserDTO(
                TestDataFactory.uniqueUserName(),
                TestDataFactory.uniqueEmail(),
                TestDataFactory.uniquePassword());
        userApi.register(user).then().statusCode(201);

        // --- 2. UI: login + create note ---
        NotesPage notes = new LoginPage().loginAs(user.getEmail(), user.getPassword());
        notes.createNote(category, title, desc);
        Assert.assertTrue(notes.isNoteVisible(title),
                "[" + tcid + "] Pre-condition: note must be visible in UI.");

        var uiCard = notes.findNote(title).orElseThrow();

        // --- 3. API: GET /notes for the same user ---
        String token = userApi.loginAndGetToken(user.getEmail(), user.getPassword());
        JsonPath api = notesApi.getAllNotes(token).jsonPath();

        @SuppressWarnings("unchecked")
        Map<String, Object> apiNote = (Map<String, Object>) api.getList("data").stream()
                .map(o -> (Map<String, Object>) o)
                .filter(n -> title.equals(n.get("title")))
                .findFirst()
                .orElseThrow(() -> new AssertionError(
                        "[" + tcid + "] Note '" + title + "' not found in API response"));

        // --- 4. Field-by-field comparison (TC-01) ---
        Allure.step("Compare UI vs API fields", () -> {
            Assert.assertEquals(((String) apiNote.get("category")).toLowerCase(),
                    uiCard.category().toLowerCase(),
                    "Category mismatch between UI and API");
            Assert.assertEquals(apiNote.get("title"), uiCard.title(),
                    "Title mismatch between UI and API");
            Assert.assertEquals(apiNote.get("description"), uiCard.description(),
                    "Description mismatch between UI and API");
        });
    }
}
