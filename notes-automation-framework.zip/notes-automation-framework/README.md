# Notes App — Selenium + RestAssured Hybrid Automation Framework

End-to-end automation framework for the **ExpandTesting Notes app**, covering UI, API, and Hybrid (UI ↔ API) validations. Built as the deliverable for **Section 2** of the Capstone.

**Every test case is driven from an Excel sheet — zero hardcoded test data in Java.**

## Stack

| Layer | Tech |
| --- | --- |
| Language | Java 17 |
| UI | Selenium WebDriver 4.21 |
| API | RestAssured 5.4 |
| Test runner | TestNG 7.10 (parallel `methods`) |
| Test data | Apache POI 5.2 + `TestData.xlsx` |
| Reporting | Allure 2.27 + screenshots |
| Logging | Log4j2 (console + rolling file) |
| Driver mgmt | WebDriverManager 5.8 |
| Build | Maven |

## Folder structure (exact match with PDF Section 2.1)

```
notes-automation-framework/
├── pom.xml
├── README.md
├── .gitignore
└── src/
    ├── main/java/com/notes/
    │   ├── base/        BaseUITest, BaseAPITest
    │   ├── pages/       BasePage, LoginPage, RegisterPage, NotesPage   (POM, no PageFactory)
    │   ├── api/         ApiSpecs, Endpoints, UserApiService,
    │   │                NotesApiService, models/{UserDTO, NoteDTO}
    │   ├── utils/       ExcelReader, TestDataFactory, WaitUtils,
    │   │                ScreenshotUtils, JsonUtils, RetryUtils,
    │   │                TestListener, RetryAnalyzer, RetryListener
    │   ├── drivers/     DriverFactory (ThreadLocal, multi-browser)
    │   └── config/      ConfigReader
    └── test/
        ├── java/com/notes/tests/
        │   ├── ui/      LoginTests, NoteCreationTests
        │   ├── api/     UserApiTests, NotesApiTests, NegativeApiTests
        │   └── e2e/     UiToApiSyncTests, ApiToUiSyncTests
        └── resources/
            ├── config/config.properties
            ├── log4j2.xml, allure.properties, categories.json, environment.properties
            ├── schemas/notes-list-schema.json
            ├── testdata/TestData.xlsx           ← all test data lives here
            └── suites/   regression.xml, smoke.xml, ui-suite.xml, api-suite.xml, e2e-suite.xml
```

## Excel-driven test data

All test inputs live in **`src/test/resources/testdata/TestData.xlsx`**.

Each sheet maps 1:1 to one test class via TestNG `@DataProvider`:

| Sheet | Used by | Drives |
| --- | --- | --- |
| `LoginData` | `LoginTests` | Valid / invalid / empty / malformed login |
| `NoteCreationData` | `NoteCreationTests` | Create notes in Home / Work / Personal |
| `UserApiData` | `UserApiTests` | Register + login via API |
| `NotesApiData` | `NotesApiTests` | Create note via API per category, with response-time threshold |
| `NegativeApiData` | `NegativeApiTests` | FR-09 negative scenarios (unauth, missing fields, wrong pwd, invalid category) |
| `E2EData` | `UiToApiSyncTests`, `ApiToUiSyncTests` | Hybrid UI↔API flows |

### `AUTO_GEN` token

A cell containing the literal string `AUTO_GEN` is replaced at runtime with a unique UUID-based value by `ExcelReader` + `TestDataFactory`. The replacement is column-aware:

| Column header contains | Replaced with |
| --- | --- |
| `email` | `qa_<uuid>@autotest.io` |
| `password` | `Test@<uuid>1` |
| `name` (not "description") | `QA-User-<uuid>` |
| `title` | `Note-<uuid>` |
| `description` | `Auto-generated description <uuid>` |

This keeps parallel tests collision-free without needing per-test setup logic.

### Adding a new test case

1. Open `TestData.xlsx`
2. Add a row to the relevant sheet
3. Run the suite — no Java change needed

## Run

```bash
# Default (regression suite)
mvn clean test

# Profiles
mvn clean test -Psmoke
mvn clean test -Pui
mvn clean test -Papi
mvn clean test -Pe2e

# Override config at runtime
mvn clean test -Dbrowser=firefox -Dheadless=true
mvn clean test -Dapi.max.response.ms=1500

# Pick a specific TestNG suite directly
mvn clean test -Dsuite=src/test/resources/suites/e2e-suite.xml
```

## Reports

```bash
mvn allure:serve              # live Allure report
mvn allure:report             # static report -> target/site/allure-maven-plugin/index.html
# Screenshots                 -> target/screenshots/
# Logs                        -> target/logs/automation.log
# Surefire HTML               -> target/surefire-reports/
```

## Requirement Traceability (Section 2 coverage)

| Req ID | Sheet row(s) → Test method |
| --- | --- |
| FR-01 — UI login | `LoginData[TC-UI-01..04]` → `LoginTests.uiLogin_dataDriven`; `UserApiData[TC-API-02]` → `UserApiTests.userFlow_dataDriven` |
| FR-02 — Create note | `NoteCreationData[TC-UI-05..07]` → `NoteCreationTests.createNote_dataDriven`; `NotesApiData[TC-API-03..05]` → `NotesApiTests.createNote_dataDriven` |
| FR-03 — Instant visibility | `NoteCreationTests.createNote_dataDriven` (asserts count before/after) |
| FR-04 — GET /notes | `NotesApiTests.getAllNotes_FR04` + `getAllNotes_matchesSchema` |
| FR-05 — UI→API sync | `E2EData[TC-E2E-01]` → `UiToApiSyncTests.uiCreatedNoteIsVisibleInApi_FR05` |
| FR-06 — Delete note (API) | `NotesApiTests.deleteNote_FR06` |
| FR-07 — API→UI sync | `E2EData[TC-E2E-02]` → `ApiToUiSyncTests.apiDeletedNoteVanishesFromUi_FR07` |
| FR-08 — API < 2 s | Global `ApiSpecs.success200()` + `MaxResponseMs` column in `NotesApiData` |
| FR-09 — Negative scenarios | `NegativeApiData[TC-NEG-01..04]` → `NegativeApiTests.negativeApi_dataDriven`; `LoginData[TC-UI-02..04]` |

## Framework features (Section 2 grid coverage)

- ✅ Core Java + Selenium WebDriver 4
- ✅ RestAssured base request/response specs
- ✅ TestNG **parallel="methods"** with ThreadLocal driver
- ✅ POM **without PageFactory** — fully custom waits & actions in `BasePage`
- ✅ Explicit + JS-based waits in `WaitUtils`
- ✅ Screenshot on failure → `target/screenshots` + Allure attachment
- ✅ Allure reporting + `environment.properties` + `categories.json`
- ✅ JSON schema validation (`schemas/notes-list-schema.json`)
- ✅ Response time assertion (<2 s)
- ✅ Retry mechanism (`RetryAnalyzer` + `RetryListener` auto-applied)
- ✅ Structured logging (Log4j2, rolling)
- ✅ **Data-driven via Excel** (`ExcelReader` + `@DataProvider`)
- ✅ Multi-browser (Chrome / Firefox / Edge), headless toggle
