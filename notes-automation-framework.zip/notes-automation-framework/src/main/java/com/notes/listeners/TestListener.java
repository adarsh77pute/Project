package com.notes.listeners;

import com.notes.drivers.DriverFactory;
import com.notes.utils.ScreenshotUtils;
import io.qameta.allure.Allure;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

/**
 * Listens for test events.
 *  - on failure: capture screenshot, attach to Allure, log stack trace
 *  - on skip: log
 *  - on success: log
 */
public class TestListener implements ITestListener {

    private static final Logger log = LogManager.getLogger(TestListener.class);

    @Override
    public void onStart(ITestContext context) {
        log.info("===== Suite START: {} =====", context.getName());
    }

    @Override
    public void onFinish(ITestContext context) {
        log.info("===== Suite END: {} | passed={} failed={} skipped={} =====",
                context.getName(),
                context.getPassedTests().size(),
                context.getFailedTests().size(),
                context.getSkippedTests().size());
    }

    @Override
    public void onTestSuccess(ITestResult r) {
        log.info("[PASS] {}", r.getMethod().getMethodName());
    }

    @Override
    public void onTestFailure(ITestResult r) {
        String name = r.getMethod().getMethodName();
        log.error("[FAIL] {} | {}", name,
                r.getThrowable() != null ? r.getThrowable().getMessage() : "no message");

        WebDriver d = safeDriver();
        if (d != null) {
            // Save to /target/screenshots + attach bytes to Allure
            ScreenshotUtils.capture(name);
            ScreenshotUtils.attachToAllure(name);
        }
        if (r.getThrowable() != null) {
            Allure.addAttachment("Stack Trace", "text/plain",
                    stack(r.getThrowable()), ".txt");
        }
    }

    @Override
    public void onTestSkipped(ITestResult r) {
        log.warn("[SKIP] {}", r.getMethod().getMethodName());
    }

    private WebDriver safeDriver() {
        try { return DriverFactory.getDriver(); }
        catch (IllegalStateException e) { return null; }  // API tests have no driver
    }

    private String stack(Throwable t) {
        StringBuilder sb = new StringBuilder(t.toString()).append("\n");
        for (StackTraceElement el : t.getStackTrace()) sb.append("\tat ").append(el).append("\n");
        return sb.toString();
    }
}
