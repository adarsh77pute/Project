package com.notes.tests.api;

import com.notes.api.NotesApiService;
import com.notes.api.UserApiService;
import com.notes.api.models.NoteDTO;
import com.notes.api.models.UserDTO;
import com.notes.base.BaseAPITest;
import com.notes.utils.TestDataFactory;
import io.qameta.allure.*;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;

@Epic("Notes App")
@Feature("API - Notes CRUD")
public class NotesApiTests extends BaseAPITest {

    private final UserApiService userApi = new UserApiService();
    private final NotesApiService notesApi = new NotesApiService();
    private String token;

    @BeforeClass
    public void registerUserAndLogin() {
        UserDTO u = new UserDTO(
                TestDataFactory.uniqueUserName(),
                TestDataFactory.uniqueEmail(),
                TestDataFactory.uniquePassword());
        userApi.register(u).then().statusCode(201);
        token = userApi.loginAndGetToken(u.getEmail(), u.getPassword());
    }

    @Test(description = "TS-05 / FR-04: GET /notes returns 200 + array",
            groups = {"smoke", "api", "regression"})
    @Severity(SeverityLevel.BLOCKER)
    public void getAllNotes_FR04() {
        Response r = notesApi.getAllNotes(token);
        r.then()
                .statusCode(200)
                .body("success", equalTo(true))
                .body("data", notNullValue())
                .time(lessThan(2000L));   // FR-08
    }

    @Test(description = "Schema validation — GET /notes matches contract",
            groups = {"api", "regression"})
    @Severity(SeverityLevel.NORMAL)
    public void getAllNotes_matchesSchema() {
        notesApi.getAllNotes(token)
                .then()
                .assertThat()
                .body(JsonSchemaValidator.matchesJsonSchemaInClasspath(
                        "schemas/notes-list-schema.json"));
    }

    @Test(description = "FR-02 (API equivalent): POST /notes creates a note",
            groups = {"smoke", "api", "regression"})
    @Severity(SeverityLevel.BLOCKER)
    public void createNote() {
        NoteDTO note = new NoteDTO("Home",
                TestDataFactory.uniqueNoteTitle(),
                TestDataFactory.uniqueNoteDescription());

        Response r = notesApi.createNote(token, note);
        r.then()
                .statusCode(200)
                .body("success", equalTo(true))
                .body("data.title", equalTo(note.getTitle()))
                .body("data.id", notNullValue())
                .time(lessThan(2000L));
    }

    @Test(description = "TS-07 / FR-06: DELETE /notes/{id} removes the note",
            groups = {"api", "regression"})
    @Severity(SeverityLevel.CRITICAL)
    public void deleteNote_FR06() {
        NoteDTO note = new NoteDTO("Work",
                TestDataFactory.uniqueNoteTitle(),
                TestDataFactory.uniqueNoteDescription());
        String id = notesApi.createAndGetId(token, note);

        notesApi.deleteNote(token, id)
                .then()
                .statusCode(200)
                .body("success", equalTo(true))
                .time(lessThan(2000L));

        // Verify removal — GET by id should now be 404
        Assert.assertEquals(notesApi.getNoteById(token, id).statusCode(), 404,
                "Deleted note must return 404 on subsequent GET.");
    }

    @Test(description = "TS-09 / FR-08: All API responses respond within 2s",
            groups = {"api", "regression", "performance"})
    @Severity(SeverityLevel.CRITICAL)
    public void allEndpointsRespondUnder2s_FR08() {
        notesApi.getAllNotes(token).then().time(lessThan(2000L));

        NoteDTO note = new NoteDTO("Personal",
                TestDataFactory.uniqueNoteTitle(),
                TestDataFactory.uniqueNoteDescription());
        String id = notesApi.createAndGetId(token, note);

        notesApi.getNoteById(token, id).then().time(lessThan(2000L));
        notesApi.deleteNote(token, id).then().time(lessThan(2000L));
    }
}
