# Notes App — Selenium + RestAssured Hybrid Automation Framework

End-to-end automation framework for the **ExpandTesting Notes app**, covering UI, API, and Hybrid (UI ↔ API) validations. Built as the deliverable for **Section 2** of the Capstone — *Framework Engineering, UI Automation, API Automation & Hybrid E2E Tests*.

## Stack

| Layer | Tech |
| --- | --- |
| Language | Java 17 |
| UI | Selenium WebDriver 4.21 |
| API | RestAssured 5.4 |
| Test runner | TestNG 7.10 (parallel `methods`) |
| Reporting | Allure 2.27 + screenshots |
| Logging | Log4j2 (console + rolling file) |
| Driver mgmt | WebDriverManager 5.8 |
| Build | Maven |

## Folder structure

```
notes-automation-framework/
├── pom.xml
├── src/
│   ├── main/java/com/notes/
│   │   ├── base/         BaseUITest, BaseAPITest
│   │   ├── pages/        BasePage, LoginPage, RegisterPage, NotesPage  (POM, no PageFactory)
│   │   ├── api/          ApiSpecs, Endpoints, UserApiService, NotesApiService, models/
│   │   ├── drivers/      DriverFactory (ThreadLocal, multi-browser)
│   │   ├── utils/        WaitUtils, ScreenshotUtils, JsonUtils, TestDataFactory, RetryUtils
│   │   ├── listeners/    TestListener, RetryAnalyzer, RetryListener
│   │   └── config/       ConfigReader
│   └── test/
│       ├── java/com/notes/tests/
│       │   ├── ui/       LoginTests, NoteCreationTests
│       │   ├── api/      UserApiTests, NotesApiTests, NegativeApiTests
│       │   └── e2e/      UiToApiSyncTests, ApiToUiSyncTests
│       └── resources/
│           ├── config/config.properties
│           ├── log4j2.xml
│           ├── allure.properties
│           ├── categories.json
│           ├── environment.properties
│           ├── schemas/notes-list-schema.json
│           └── suites/   regression.xml, smoke.xml, ui-suite.xml, api-suite.xml, e2e-suite.xml
```

## Run

```bash
# Default (regression)
mvn clean test

# Profiles
mvn clean test -Psmoke
mvn clean test -Pui
mvn clean test -Papi
mvn clean test -Pe2e

# Override config at runtime
mvn clean test -Dbrowser=firefox -Dheadless=true
mvn clean test -Dapi.max.response.ms=1500

# Pick a specific TestNG suite
mvn clean test -Dsuite=src/test/resources/suites/e2e-suite.xml
```

## Reports

```bash
# Allure (live)
mvn allure:serve

# Allure (static)
mvn allure:report
# -> target/site/allure-maven-plugin/index.html

# Surefire (basic)
# -> target/surefire-reports/index.html

# Screenshots (on failure)
# -> target/screenshots/

# Logs
# -> target/logs/automation.log
```

## Requirement Traceability (Section 2 coverage)

| Req ID | Covered by |
|---|---|
| FR-01 — UI login | `LoginTests.validUserCanLogin_FR01`, `UserApiTests.loginReturnsToken_FR01` |
| FR-02 — Create note (UI) | `NoteCreationTests.userCanCreateNoteViaUi_FR02`, `NotesApiTests.createNote` |
| FR-03 — Instant visibility | `NoteCreationTests.noteAppearsInstantly_FR03` |
| FR-04 — GET /notes | `NotesApiTests.getAllNotes_FR04`, `NotesApiTests.getAllNotes_matchesSchema` |
| FR-05 — UI-created note in API | `UiToApiSyncTests.uiCreatedNoteIsVisibleInApi_FR05` |
| FR-06 — Delete note (API) | `NotesApiTests.deleteNote_FR06` |
| FR-07 — Deleted note gone from UI | `ApiToUiSyncTests.apiDeletedNoteVanishesFromUi_FR07` |
| FR-08 — API response < 2s | `NotesApiTests.allEndpointsRespondUnder2s_FR08` + every API test asserts `time(lessThan(2000L))` |
| FR-09 — Negative scenarios | `NegativeApiTests.*`, `LoginTests.invalidCredentialsAreRejected_FR01_FR09` |

## Framework features (from the capstone grid)

- ✅ Core Java + Selenium WebDriver 4
- ✅ RestAssured with base request/response specs
- ✅ TestNG **parallel="methods"** with ThreadLocal driver
- ✅ POM **without PageFactory** — fully custom waits & actions in `BasePage`
- ✅ Explicit + JS-based waits in `WaitUtils`
- ✅ Screenshot on failure → `target/screenshots` + Allure attachment
- ✅ Allure reporting + `environment.properties` + `categories.json`
- ✅ JSON schema validation (`schemas/notes-list-schema.json`)
- ✅ Response time assertion (<2s)
- ✅ Retry mechanism (`RetryAnalyzer` + `RetryListener` auto-applied)
- ✅ Structured logging (Log4j2, rolling)
- ✅ Test data factory for parallel-safe unique data
- ✅ Multi-browser (Chrome / Firefox / Edge), headless toggle
