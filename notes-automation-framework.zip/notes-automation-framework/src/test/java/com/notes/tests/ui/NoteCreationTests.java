package com.notes.tests.ui;

import com.notes.api.UserApiService;
import com.notes.api.models.UserDTO;
import com.notes.base.BaseUITest;
import com.notes.pages.LoginPage;
import com.notes.pages.NotesPage;
import com.notes.utils.ExcelReader;
import com.notes.utils.TestDataFactory;
import io.qameta.allure.*;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Map;

/**
 * UI note-creation tests. Driven entirely from
 * TestData.xlsx :: sheet "NoteCreationData".
 *
 * Covers FR-02 (create note via UI) and FR-03 (instant visibility).
 */
@Epic("Notes App")
@Feature("UI - Notes CRUD")
public class NoteCreationTests extends BaseUITest {

    private final UserApiService userApi = new UserApiService();

    @DataProvider(name = "noteCreationData")
    public Object[][] noteCreationData() {
        return ExcelReader.asDataProvider("NoteCreationData");
    }

    @Test(dataProvider = "noteCreationData",
            description = "FR-02 / FR-03 - Data-driven UI note creation",
            groups = {"smoke", "ui", "regression"})
    @Story("Create note via UI with instant visibility")
    @Severity(SeverityLevel.BLOCKER)
    public void createNote_dataDriven(Map<String, String> row) {
        String tcid     = row.get("TCID");
        String category = row.get("Category");
        String title    = row.get("Title");
        String desc     = row.get("NoteDescription");

        Allure.parameter("TCID", tcid);
        Allure.parameter("Description", row.get("Description"));

        // Fixture: register a fresh user via API so the test is hermetic
        UserDTO user = new UserDTO(
                TestDataFactory.uniqueUserName(),
                TestDataFactory.uniqueEmail(),
                TestDataFactory.uniquePassword());
        userApi.register(user).then().statusCode(201);

        NotesPage notes = new LoginPage().loginAs(user.getEmail(), user.getPassword());

        int before = notes.countVisibleNotes();
        notes.createNote(category, title, desc);
        int after = notes.countVisibleNotes();

        // FR-02: note exists
        Assert.assertTrue(notes.isNoteVisible(title),
                "[" + tcid + "] Note should be visible in dashboard.");
        // FR-03: appears without refresh
        Assert.assertEquals(after, before + 1,
                "[" + tcid + "] Note count should grow by 1 without page refresh.");
    }
}
