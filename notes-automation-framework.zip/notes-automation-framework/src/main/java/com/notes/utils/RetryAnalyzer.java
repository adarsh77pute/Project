package com.notes.utils;

import com.notes.config.ConfigReader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

/**
 * Retries a failed test up to `retry.count` times.
 * Auto-applied to every @Test by RetryListener.
 */
public class RetryAnalyzer implements IRetryAnalyzer {

    private static final Logger log = LogManager.getLogger(RetryAnalyzer.class);
    private static final int MAX = ConfigReader.getInt("retry.count", 1);
    private int count = 0;

    @Override
    public boolean retry(ITestResult result) {
        if (count < MAX) {
            count++;
            log.warn("Retrying {} ({}/{})", result.getMethod().getMethodName(), count, MAX);
            return true;
        }
        return false;
    }
}
