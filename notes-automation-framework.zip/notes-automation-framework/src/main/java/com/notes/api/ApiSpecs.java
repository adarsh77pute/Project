package com.notes.api;

import com.notes.config.ConfigReader;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

import java.util.concurrent.TimeUnit;

import static org.hamcrest.Matchers.lessThan;

/**
 * Centralised RestAssured specs.
 *
 * - request()  : base headers + content type
 * - authed(token) : same + Bearer token
 * - success200() : 200 + JSON + response time < 2s (FR-08)
 */
public final class ApiSpecs {

    private static final long MAX_RESPONSE_MS =
            ConfigReader.getInt("api.max.response.ms", 2000);

    private ApiSpecs() {}

    public static RequestSpecification request() {
        return new RequestSpecBuilder()
                .setBaseUri(ConfigReader.get("api.base.url"))
                .setContentType(ContentType.JSON)
                .setAccept(ContentType.JSON)
                .addHeader("User-Agent", "NotesAutomationFramework/1.0")
                .build();
    }

    public static RequestSpecification authed(String token) {
        return new RequestSpecBuilder()
                .addRequestSpecification(request())
                .addHeader("X-Auth-Token", token)
                .build();
    }

    public static ResponseSpecification success200() {
        return new ResponseSpecBuilder()
                .expectStatusCode(200)
                .expectContentType(ContentType.JSON)
                .expectResponseTime(lessThan(MAX_RESPONSE_MS), TimeUnit.MILLISECONDS)
                .build();
    }

    public static ResponseSpecification created201() {
        return new ResponseSpecBuilder()
                .expectStatusCode(200)  // ExpandTesting Notes returns 200 for create
                .expectContentType(ContentType.JSON)
                .expectResponseTime(lessThan(MAX_RESPONSE_MS), TimeUnit.MILLISECONDS)
                .build();
    }

    public static ResponseSpecification badRequest400() {
        return new ResponseSpecBuilder()
                .expectStatusCode(400)
                .expectContentType(ContentType.JSON)
                .build();
    }

    public static ResponseSpecification unauthorized401() {
        return new ResponseSpecBuilder()
                .expectStatusCode(401)
                .expectContentType(ContentType.JSON)
                .build();
    }
}
