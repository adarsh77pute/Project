package com.notes.api;

import com.notes.api.models.NoteDTO;
import io.qameta.allure.Step;
import io.restassured.response.Response;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static io.restassured.RestAssured.given;

/**
 * Service layer wrapping all /notes endpoints.
 */
public class NotesApiService {

    private static final Logger log = LogManager.getLogger(NotesApiService.class);

    @Step("API: GET /notes")
    public Response getAllNotes(String token) {
        log.info("GET {}", Endpoints.NOTES);
        return given()
                .spec(ApiSpecs.authed(token))
                .when()
                .get(Endpoints.NOTES);
    }

    @Step("API: GET /notes (no auth)")
    public Response getAllNotesNoAuth() {
        return given()
                .spec(ApiSpecs.request())
                .when()
                .get(Endpoints.NOTES);
    }

    @Step("API: POST /notes | title={note.title}")
    public Response createNote(String token, NoteDTO note) {
        log.info("POST {} | title={}", Endpoints.NOTES, note.getTitle());
        return given()
                .spec(ApiSpecs.authed(token))
                .body(note)
                .when()
                .post(Endpoints.NOTES);
    }

    @Step("API: GET /notes/{id}")
    public Response getNoteById(String token, String id) {
        return given()
                .spec(ApiSpecs.authed(token))
                .pathParam("id", id)
                .when()
                .get(Endpoints.NOTE_BY_ID);
    }

    @Step("API: PUT /notes/{id}")
    public Response updateNote(String token, String id, NoteDTO note) {
        return given()
                .spec(ApiSpecs.authed(token))
                .pathParam("id", id)
                .body(note)
                .when()
                .put(Endpoints.NOTE_BY_ID);
    }

    @Step("API: DELETE /notes/{id}")
    public Response deleteNote(String token, String id) {
        log.info("DELETE /notes/{}", id);
        return given()
                .spec(ApiSpecs.authed(token))
                .pathParam("id", id)
                .when()
                .delete(Endpoints.NOTE_BY_ID);
    }

    /** Convenience: create and return the new note id. */
    public String createAndGetId(String token, NoteDTO note) {
        Response r = createNote(token, note);
        if (r.statusCode() != 200) {
            throw new RuntimeException(
                    "Create note failed: " + r.statusCode() + " body=" + r.asString());
        }
        return r.jsonPath().getString("data.id");
    }
}
