package com.notes.pages;

import io.qameta.allure.Step;
import org.openqa.selenium.By;

/**
 * Login screen of the Notes app.
 * Note: locators here are validated against
 *   https://practice.expandtesting.com/notes/app/login
 * If the DOM shifts, change ONLY the By constants below.
 */
public class LoginPage extends BasePage {

    private final By emailInput      = By.id("email");
    private final By passwordInput   = By.id("password");
    private final By loginButton     = By.cssSelector("button[type='submit']");
    private final By errorBanner     = By.cssSelector("[data-testid='alert-message'], .alert");
    private final By registerLink    = By.linkText("Click here to register");

    @Step("Enter email: {email}")
    public LoginPage enterEmail(String email) {
        type(emailInput, email);
        return this;
    }

    @Step("Enter password")
    public LoginPage enterPassword(String password) {
        type(passwordInput, password);
        return this;
    }

    @Step("Click Login")
    public NotesPage clickLogin() {
        click(loginButton);
        return new NotesPage();
    }

    @Step("Login with credentials [{email}]")
    public NotesPage loginAs(String email, String password) {
        return enterEmail(email)
                .enterPassword(password)
                .clickLogin();
    }

    @Step("Attempt invalid login")
    public LoginPage loginExpectingFailure(String email, String password) {
        enterEmail(email).enterPassword(password);
        click(loginButton);
        return this;
    }

    public String getErrorMessage() {
        return getText(errorBanner);
    }

    public boolean isOnLoginPage() {
        return isDisplayed(emailInput) && isDisplayed(passwordInput);
    }

    public RegisterPage goToRegister() {
        click(registerLink);
        return new RegisterPage();
    }
}
