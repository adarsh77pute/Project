package com.notes.api.models;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class NoteDTO {

    private String category;     // Home / Work / Personal
    private String title;
    private String description;
    private Boolean completed;

    public NoteDTO() {}

    public NoteDTO(String category, String title, String description) {
        this.category = category;
        this.title = title;
        this.description = description;
        this.completed = false;
    }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public Boolean getCompleted() { return completed; }
    public void setCompleted(Boolean completed) { this.completed = completed; }
}
