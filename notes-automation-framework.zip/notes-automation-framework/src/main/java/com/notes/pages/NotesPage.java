package com.notes.pages;

import com.notes.utils.WaitUtils;
import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * Notes dashboard — list, create, delete, filter.
 * Card structure (as observed on the Expand-Testing Notes app):
 *   <div class="note-item">
 *     <span class="note-category">Home</span>
 *     <h4 class="note-title">My title</h4>
 *     <p class="note-description">desc...</p>
 *     <button>Delete</button>
 *   </div>
 */
public class NotesPage extends BasePage {

    private final By addNoteButton    = By.xpath("//button[normalize-space()='+ Add Note']");
    private final By categorySelect   = By.id("category");
    private final By completedCheckbox= By.id("completed");
    private final By titleInput       = By.id("title");
    private final By descriptionInput = By.id("description");
    private final By createButton     = By.xpath("//button[normalize-space()='Create']");

    private final By userProfileBtn   = By.id("user-menu");
    private final By logoutLink       = By.xpath("//a[contains(.,'Logout')]");

    // Notes-list locators
    private final By noteCards        = By.cssSelector("[data-testid='note-card']");
    private final By noteTitleInCard  = By.cssSelector("[data-testid='note-card-title']");
    private final By noteCategoryInCard = By.cssSelector("[data-testid='note-card-category']");
    private final By noteDescInCard   = By.cssSelector("[data-testid='note-card-description']");

    public boolean isOnDashboard() {
        return isDisplayed(addNoteButton);
    }

    @Step("Open 'Add Note' form")
    public NotesPage openAddNoteForm() {
        click(addNoteButton);
        WaitUtils.waitForVisible(titleInput);
        return this;
    }

    @Step("Create note | category={category}, title={title}")
    public NotesPage createNote(String category, String title, String description) {
        openAddNoteForm();
        selectByVisibleText(categorySelect, category);
        type(titleInput, title);
        type(descriptionInput, description);
        click(createButton);
        WaitUtils.waitForDomReady();
        return this;
    }

    @Step("Check if note with title '{title}' is visible")
    public boolean isNoteVisible(String title) {
        return findAll(noteCards).stream()
                .map(card -> card.findElement(noteTitleInCard).getText().trim())
                .anyMatch(t -> t.equalsIgnoreCase(title));
    }

    /** Read a note card's details by title. Returns Optional.empty() if not found. */
    public Optional<NoteCardData> findNote(String title) {
        for (WebElement card : findAll(noteCards)) {
            String cardTitle = card.findElement(noteTitleInCard).getText().trim();
            if (cardTitle.equalsIgnoreCase(title)) {
                return Optional.of(new NoteCardData(
                        card.findElement(noteCategoryInCard).getText().trim(),
                        cardTitle,
                        card.findElement(noteDescInCard).getText().trim()
                ));
            }
        }
        return Optional.empty();
    }

    public int countVisibleNotes() {
        return findAll(noteCards).size();
    }

    @Step("Logout")
    public LoginPage logout() {
        click(userProfileBtn);
        click(logoutLink);
        return new LoginPage();
    }

    /** DTO returned by findNote for UI ↔ API comparisons. */
    public record NoteCardData(String category, String title, String description) {
        public boolean matches(String apiCategory, String apiTitle, String apiDescription) {
            return Objects.equals(category.toLowerCase(), apiCategory.toLowerCase())
                    && Objects.equals(title, apiTitle)
                    && Objects.equals(description, apiDescription);
        }
    }
}
