package com.notes.utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.io.IOException;

public final class JsonUtils {

    private static final ObjectMapper MAPPER = new ObjectMapper()
            .enable(SerializationFeature.INDENT_OUTPUT);

    private JsonUtils() {}

    public static <T> T fromString(String json, Class<T> type) throws IOException {
        return MAPPER.readValue(json, type);
    }
    public static JsonNode tree(String json) throws IOException {
        return MAPPER.readTree(json);
    }
    public static String toJson(Object obj) throws IOException {
        return MAPPER.writeValueAsString(obj);
    }
    public static String toPretty(Object obj) throws IOException {
        return MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(obj);
    }
    public static ObjectMapper mapper() { return MAPPER; }
}
