package com.notes.tests.api;

import com.notes.api.NotesApiService;
import com.notes.api.UserApiService;
import com.notes.api.models.NoteDTO;
import com.notes.api.models.UserDTO;
import com.notes.base.BaseAPITest;
import com.notes.utils.TestDataFactory;
import io.qameta.allure.*;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.equalTo;

@Epic("Notes App")
@Feature("API - Negative scenarios")
public class NegativeApiTests extends BaseAPITest {

    private final UserApiService userApi   = new UserApiService();
    private final NotesApiService notesApi = new NotesApiService();

    @Test(description = "TS-10 / FR-09: GET /notes without token → 401",
            groups = {"api", "regression", "negative"})
    @Severity(SeverityLevel.CRITICAL)
    public void getNotesUnauthorized_FR09() {
        notesApi.getAllNotesNoAuth()
                .then()
                .statusCode(401)
                .body("success", equalTo(false));
    }

    @Test(description = "TS-11 / FR-09: POST /notes with missing fields → 400",
            groups = {"api", "regression", "negative"})
    @Severity(SeverityLevel.NORMAL)
    public void createNoteWithMissingFields_FR09() {
        // Need a token to reach validation layer
        UserDTO u = new UserDTO(
                TestDataFactory.uniqueUserName(),
                TestDataFactory.uniqueEmail(),
                TestDataFactory.uniquePassword());
        userApi.register(u).then().statusCode(201);
        String token = userApi.loginAndGetToken(u.getEmail(), u.getPassword());

        // Send a note with empty title & description
        NoteDTO bad = new NoteDTO("Home", "", "");
        notesApi.createNote(token, bad)
                .then()
                .statusCode(400)
                .body("success", equalTo(false));
    }

    @Test(description = "FR-09: Login with wrong password → 401",
            groups = {"api", "regression", "negative"})
    @Severity(SeverityLevel.CRITICAL)
    public void loginWithWrongPassword_FR09() {
        UserDTO u = new UserDTO(
                TestDataFactory.uniqueUserName(),
                TestDataFactory.uniqueEmail(),
                TestDataFactory.uniquePassword());
        userApi.register(u).then().statusCode(201);

        userApi.login(new UserDTO(u.getEmail(), "WrongPass!123"))
                .then()
                .statusCode(401)
                .body("success", equalTo(false));
    }
}
