package com.notes.tests.api;

import com.notes.api.NotesApiService;
import com.notes.api.UserApiService;
import com.notes.api.models.NoteDTO;
import com.notes.api.models.UserDTO;
import com.notes.base.BaseAPITest;
import com.notes.utils.ExcelReader;
import com.notes.utils.TestDataFactory;
import io.qameta.allure.*;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Map;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.lessThan;
import static org.hamcrest.Matchers.notNullValue;

/**
 * Notes CRUD API tests. Data driven by TestData.xlsx :: sheet "NotesApiData".
 * Covers FR-04 (GET), FR-02-API (POST), FR-06 (DELETE), FR-08 (response time).
 */
@Epic("Notes App")
@Feature("API - Notes CRUD")
public class NotesApiTests extends BaseAPITest {

    private final UserApiService userApi   = new UserApiService();
    private final NotesApiService notesApi = new NotesApiService();
    private String token;

    @BeforeClass
    public void registerOnceAndLogin() {
        UserDTO u = new UserDTO(
                TestDataFactory.uniqueUserName(),
                TestDataFactory.uniqueEmail(),
                TestDataFactory.uniquePassword());
        userApi.register(u).then().statusCode(201);
        token = userApi.loginAndGetToken(u.getEmail(), u.getPassword());
    }

    @DataProvider(name = "notesApiData")
    public Object[][] notesApiData() {
        return ExcelReader.asDataProvider("NotesApiData");
    }

    @Test(description = "FR-04 - GET /notes returns 200 + array",
            groups = {"smoke", "api", "regression"})
    @Severity(SeverityLevel.BLOCKER)
    public void getAllNotes_FR04() {
        Response r = notesApi.getAllNotes(token);
        r.then()
                .statusCode(200)
                .body("success", equalTo(true))
                .body("data", notNullValue())
                .time(lessThan(2000L));   // FR-08
    }

    @Test(description = "Schema validation - GET /notes matches contract",
            groups = {"api", "regression"})
    @Severity(SeverityLevel.NORMAL)
    public void getAllNotes_matchesSchema() {
        notesApi.getAllNotes(token).then()
                .assertThat()
                .body(JsonSchemaValidator.matchesJsonSchemaInClasspath(
                        "schemas/notes-list-schema.json"));
    }

    @Test(dataProvider = "notesApiData",
            description = "FR-02 / FR-08 - Data-driven note creation via API",
            groups = {"smoke", "api", "regression"})
    @Severity(SeverityLevel.BLOCKER)
    public void createNote_dataDriven(Map<String, String> row) {
        String tcid     = row.get("TCID");
        String category = row.get("Category");
        String title    = row.get("Title");
        String desc     = row.get("NoteDescription");
        int expected    = Integer.parseInt(row.get("ExpectedStatus"));
        long maxMs      = Long.parseLong(row.get("MaxResponseMs"));

        Allure.parameter("TCID", tcid);
        Allure.parameter("Description", row.get("Description"));

        Response r = notesApi.createNote(token, new NoteDTO(category, title, desc));
        r.then()
                .statusCode(expected)
                .body("success", equalTo(true))
                .body("data.title", equalTo(title))
                .body("data.id", notNullValue())
                .time(lessThan(maxMs));
    }

    @Test(description = "FR-06 - DELETE /notes/{id} removes the note",
            groups = {"api", "regression"})
    @Severity(SeverityLevel.CRITICAL)
    public void deleteNote_FR06() {
        NoteDTO note = new NoteDTO("Work",
                TestDataFactory.uniqueNoteTitle(),
                TestDataFactory.uniqueNoteDescription());
        String id = notesApi.createAndGetId(token, note);

        notesApi.deleteNote(token, id).then()
                .statusCode(200)
                .body("success", equalTo(true))
                .time(lessThan(2000L));

        Assert.assertEquals(notesApi.getNoteById(token, id).statusCode(), 404,
                "Deleted note should return 404 on subsequent GET.");
    }
}
