package com.notes.utils;

import com.notes.drivers.DriverFactory;
import io.qameta.allure.Attachment;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public final class ScreenshotUtils {

    private static final Logger log = LogManager.getLogger(ScreenshotUtils.class);
    private static final String DIR = "target/screenshots";
    private static final DateTimeFormatter TS =
            DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS");

    private ScreenshotUtils() {}

    /** Save PNG to disk; returns absolute path, or null if no driver. */
    public static String capture(String testName) {
        if (!DriverFactory.hasDriver()) return null;
        WebDriver drv = DriverFactory.getDriver();
        try {
            File src = ((TakesScreenshot) drv).getScreenshotAs(OutputType.FILE);
            String safe = testName.replaceAll("[^a-zA-Z0-9-_]", "_");
            String file = safe + "_" + LocalDateTime.now().format(TS) + ".png";
            Path target = Paths.get(DIR, file);
            Files.createDirectories(target.getParent());
            Files.copy(src.toPath(), target);
            log.info("Screenshot saved: {}", target.toAbsolutePath());
            return target.toAbsolutePath().toString();
        } catch (IOException e) {
            log.error("Screenshot capture failed", e);
            return null;
        }
    }

    /** Attach PNG bytes to Allure. */
    @Attachment(value = "Screenshot - {testName}", type = "image/png")
    public static byte[] attachToAllure(String testName) {
        if (!DriverFactory.hasDriver()) return new byte[0];
        try {
            return ((TakesScreenshot) DriverFactory.getDriver()).getScreenshotAs(OutputType.BYTES);
        } catch (Exception e) {
            log.warn("Could not attach screenshot: {}", e.getMessage());
            return new byte[0];
        }
    }
}
