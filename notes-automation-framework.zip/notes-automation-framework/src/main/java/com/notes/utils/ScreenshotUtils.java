package com.notes.utils;

import com.notes.drivers.DriverFactory;
import io.qameta.allure.Attachment;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public final class ScreenshotUtils {

    private static final Logger log = LogManager.getLogger(ScreenshotUtils.class);
    private static final String DIR = "target/screenshots";
    private static final DateTimeFormatter TS =
            DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS");

    private ScreenshotUtils() {}

    /** Save PNG to target/screenshots and return the absolute path. */
    public static String capture(String testName) {
        WebDriver drv = DriverFactory.getDriver();
        if (drv == null) return null;
        try {
            File src = ((TakesScreenshot) drv).getScreenshotAs(OutputType.FILE);
            String safeName = testName.replaceAll("[^a-zA-Z0-9-_]", "_");
            String fileName = safeName + "_" + LocalDateTime.now().format(TS) + ".png";
            Path target = Paths.get(DIR, fileName);
            Files.createDirectories(target.getParent());
            Files.copy(src.toPath(), target);
            log.info("Screenshot saved: {}", target.toAbsolutePath());
            return target.toAbsolutePath().toString();
        } catch (IOException e) {
            log.error("Screenshot capture failed", e);
            return null;
        }
    }

    /** Returns PNG bytes for Allure attachment. */
    @Attachment(value = "Screenshot - {testName}", type = "image/png")
    public static byte[] attachToAllure(String testName) {
        try {
            return ((TakesScreenshot) DriverFactory.getDriver()).getScreenshotAs(OutputType.BYTES);
        } catch (Exception e) {
            log.warn("Could not attach screenshot: {}", e.getMessage());
            return new byte[0];
        }
    }
}
