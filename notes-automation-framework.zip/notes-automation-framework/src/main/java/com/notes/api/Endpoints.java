package com.notes.api;

/**
 * Central registry of API paths.
 * Keep here so route changes only touch one file.
 */
public final class Endpoints {

    private Endpoints() {}

    // Users
    public static final String USER_REGISTER  = "/users/register";
    public static final String USER_LOGIN     = "/users/login";
    public static final String USER_PROFILE   = "/users/profile";
    public static final String USER_LOGOUT    = "/users/logout";
    public static final String USER_DELETE    = "/users/delete-account";

    // Notes
    public static final String NOTES          = "/notes";
    public static final String NOTE_BY_ID     = "/notes/{id}";
}
