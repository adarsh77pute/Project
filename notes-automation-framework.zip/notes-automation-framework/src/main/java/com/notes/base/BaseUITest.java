package com.notes.base;

import com.notes.config.ConfigReader;
import com.notes.drivers.DriverFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.lang.reflect.Method;

/**
 * Base class for all UI tests.
 *
 * One driver per test method = full isolation for parallel="methods".
 * Listeners (TestListener) handle screenshots and Allure attachments.
 */
public abstract class BaseUITest {

    private static final Logger log = LogManager.getLogger(BaseUITest.class);

    @BeforeMethod(alwaysRun = true)
    public void beforeMethod(Method method) {
        log.info(">>> START UI test: {} on thread [{}]",
                method.getName(), Thread.currentThread().getName());
        DriverFactory.initDriver();
        DriverFactory.getDriver().get(ConfigReader.get("ui.base.url"));
    }

    @AfterMethod(alwaysRun = true)
    public void afterMethod(ITestResult result) {
        log.info("<<< END UI test: {} | status={}",
                result.getMethod().getMethodName(),
                statusName(result.getStatus()));
        DriverFactory.quitDriver();
    }

    protected WebDriver driver() {
        return DriverFactory.getDriver();
    }

    private String statusName(int status) {
        return switch (status) {
            case ITestResult.SUCCESS -> "PASS";
            case ITestResult.FAILURE -> "FAIL";
            case ITestResult.SKIP -> "SKIP";
            default -> "UNKNOWN";
        };
    }
}
