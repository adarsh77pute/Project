package com.notes.config;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.InputStream;
import java.util.Properties;

/**
 * Singleton config reader.
 * Precedence: System property (-Dkey=value) > config.properties > default.
 *
 * Usage:
 *   ConfigReader.get("ui.base.url")
 *   ConfigReader.getInt("explicit.wait.seconds", 15)
 */
public final class ConfigReader {

    private static final Logger log = LogManager.getLogger(ConfigReader.class);
    private static final String CONFIG_FILE = "config/config.properties";
    private static final Properties PROPS = new Properties();

    static {
        try (InputStream in = ConfigReader.class
                .getClassLoader()
                .getResourceAsStream(CONFIG_FILE)) {
            if (in == null) {
                throw new IllegalStateException(
                        "config.properties not found on classpath at " + CONFIG_FILE);
            }
            PROPS.load(in);
            log.info("Loaded {} keys from {}", PROPS.size(), CONFIG_FILE);
        } catch (Exception e) {
            log.error("Failed to load config", e);
            throw new RuntimeException(e);
        }
    }

    private ConfigReader() {}

    public static String get(String key) {
        // System property wins — lets CI override values without rebuilding
        String sysProp = System.getProperty(key);
        if (sysProp != null && !sysProp.isBlank()) return sysProp.trim();

        String val = PROPS.getProperty(key);
        if (val == null) {
            throw new IllegalArgumentException("Missing config key: " + key);
        }
        return val.trim();
    }

    public static String get(String key, String defaultValue) {
        String sysProp = System.getProperty(key);
        if (sysProp != null && !sysProp.isBlank()) return sysProp.trim();
        return PROPS.getProperty(key, defaultValue).trim();
    }

    public static int getInt(String key, int defaultValue) {
        try {
            return Integer.parseInt(get(key, String.valueOf(defaultValue)));
        } catch (NumberFormatException e) {
            log.warn("Invalid int for key {}, using default {}", key, defaultValue);
            return defaultValue;
        }
    }

    public static boolean getBoolean(String key, boolean defaultValue) {
        return Boolean.parseBoolean(get(key, String.valueOf(defaultValue)));
    }
}
