package com.notes.tests.e2e;

import com.notes.api.NotesApiService;
import com.notes.api.UserApiService;
import com.notes.api.models.UserDTO;
import com.notes.base.BaseUITest;
import com.notes.config.ConfigReader;
import com.notes.pages.LoginPage;
import com.notes.pages.NotesPage;
import com.notes.utils.TestDataFactory;
import io.qameta.allure.*;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Hybrid E2E — TC-01 / FR-05.
 * A note created via the UI MUST also appear in the GET /notes API response,
 * with every field matching exactly (Category, Title, Description).
 */
@Epic("Notes App")
@Feature("Hybrid E2E - UI → API sync")
public class UiToApiSyncTests extends BaseUITest {

    private final UserApiService userApi   = new UserApiService();
    private final NotesApiService notesApi = new NotesApiService();

    @BeforeClass
    public void initApi() {
        RestAssured.baseURI = ConfigReader.get("api.base.url");
    }

    @Test(description = "TC-E2E-01 / FR-05: Note created in UI appears in GET /notes API",
            groups = {"e2e", "regression", "smoke"})
    @Story("UI to API data consistency")
    @Severity(SeverityLevel.BLOCKER)
    public void uiCreatedNoteIsVisibleInApi_FR05() {
        // -------- Step 1: Fixture — register user via API --------
        UserDTO user = new UserDTO(
                TestDataFactory.uniqueUserName(),
                TestDataFactory.uniqueEmail(),
                TestDataFactory.uniquePassword());
        userApi.register(user).then().statusCode(201);

        // -------- Step 2: UI — login + create note --------
        String category = "Home";
        String title    = TestDataFactory.uniqueNoteTitle();
        String desc     = TestDataFactory.uniqueNoteDescription();

        NotesPage notes = new LoginPage().loginAs(user.getEmail(), user.getPassword());
        notes.createNote(category, title, desc);
        Assert.assertTrue(notes.isNoteVisible(title),
                "Pre-condition: note must be visible in UI before API check.");

        var uiCard = notes.findNote(title).orElseThrow();

        // -------- Step 3: API — get the same user's notes --------
        String token = userApi.loginAndGetToken(user.getEmail(), user.getPassword());
        JsonPath api = notesApi.getAllNotes(token).jsonPath();

        // Find the same note in the response
        var apiNote = api.getList("data").stream()
                .map(o -> (java.util.Map<String, Object>) o)
                .filter(n -> title.equals(n.get("title")))
                .findFirst()
                .orElseThrow(() -> new AssertionError(
                        "Note '" + title + "' not found in API response"));

        // -------- Step 4: Field-by-field comparison (TC-01) --------
        Allure.step("Compare UI vs API fields", () -> {
            Assert.assertEquals(((String) apiNote.get("category")).toLowerCase(),
                    uiCard.category().toLowerCase(),
                    "Category mismatch between UI and API");
            Assert.assertEquals(apiNote.get("title"), uiCard.title(),
                    "Title mismatch between UI and API");
            Assert.assertEquals(apiNote.get("description"), uiCard.description(),
                    "Description mismatch between UI and API");
        });
    }
}
