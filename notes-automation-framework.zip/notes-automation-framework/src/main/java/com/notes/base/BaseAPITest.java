package com.notes.base;

import com.notes.api.ApiSpecs;
import com.notes.config.ConfigReader;
import io.qameta.allure.restassured.AllureRestAssured;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

import java.lang.reflect.Method;

/** Base for API tests — configures RestAssured base URI + Allure filter. */
public abstract class BaseAPITest {

    private static final Logger log = LogManager.getLogger(BaseAPITest.class);

    @BeforeClass(alwaysRun = true)
    public void beforeApiClass() {
        RestAssured.baseURI = ConfigReader.get("api.base.url");
        RestAssured.filters(
                new RequestLoggingFilter(),
                new ResponseLoggingFilter(),
                new AllureRestAssured()
        );
        log.info("RestAssured base URI = {}", RestAssured.baseURI);
        ApiSpecs.request(); // touch so specs are built once
    }

    @BeforeMethod(alwaysRun = true)
    public void beforeApiMethod(Method method) {
        log.info(">>> START API test: {}", method.getName());
    }

    @AfterMethod(alwaysRun = true)
    public void afterApiMethod(ITestResult result) {
        log.info("<<< END API test: {} | status={}",
                result.getMethod().getMethodName(),
                statusName(result.getStatus()));
    }

    private String statusName(int s) {
        return switch (s) {
            case ITestResult.SUCCESS -> "PASS";
            case ITestResult.FAILURE -> "FAIL";
            case ITestResult.SKIP    -> "SKIP";
            default -> "UNKNOWN";
        };
    }
}
