package com.notes.tests.api;

import com.notes.api.UserApiService;
import com.notes.api.models.UserDTO;
import com.notes.base.BaseAPITest;
import com.notes.utils.ExcelReader;
import io.qameta.allure.*;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Map;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.lessThan;
import static org.hamcrest.Matchers.notNullValue;

/**
 * API user-flow tests. Driven from TestData.xlsx :: sheet "UserApiData".
 * Covers FR-01 (login) on the API layer + parts of FR-08 (response time).
 */
@Epic("Notes App")
@Feature("API - Users")
public class UserApiTests extends BaseAPITest {

    private final UserApiService userApi = new UserApiService();

    @DataProvider(name = "userApiData")
    public Object[][] userApiData() {
        return ExcelReader.asDataProvider("UserApiData");
    }

    @Test(dataProvider = "userApiData",
            description = "FR-01 - Data-driven user register + login",
            groups = {"smoke", "api", "regression"})
    @Severity(SeverityLevel.BLOCKER)
    public void userFlow_dataDriven(Map<String, String> row) {
        String tcid   = row.get("TCID");
        String name   = row.get("Name");
        String email  = row.get("Email");
        String pwd    = row.get("Password");
        int expected  = Integer.parseInt(row.get("ExpectedStatus"));

        Allure.parameter("TCID", tcid);
        Allure.parameter("Description", row.get("Description"));

        // Always register first so login rows have a known user
        Response reg = userApi.register(new UserDTO(name, email, pwd));
        reg.then().statusCode(201).time(lessThan(2000L));

        if (tcid.equals("TC-API-01")) {
            // Register-only row -> assert payload shape
            reg.then()
                    .body("success", equalTo(true))
                    .body("data.email", equalTo(email))
                    .body("data.id", notNullValue());
            Assert.assertEquals(reg.statusCode(), expected);
        } else {
            // Login row
            Response login = userApi.login(new UserDTO(email, pwd));
            login.then()
                    .statusCode(expected)
                    .body("data.token", notNullValue())
                    .time(lessThan(2000L));
            Assert.assertFalse(login.jsonPath().getString("data.token").isBlank(),
                    "[" + tcid + "] Token should be non-empty.");
        }
    }
}
