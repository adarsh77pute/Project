package com.notes.pages;

import com.notes.drivers.DriverFactory;
import com.notes.utils.WaitUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

/**
 * Shared reusable actions for every page.
 *
 * No PageFactory: locators are By constants on each page; this class wraps
 * actions in our explicit waits + structured logging.
 */
public abstract class BasePage {

    private static final Logger log = LogManager.getLogger(BasePage.class);

    protected WebDriver driver() {
        return DriverFactory.getDriver();
    }

    protected void click(By locator) {
        WebElement el = WaitUtils.waitForClickable(locator);
        log.debug("CLICK {}", locator);
        el.click();
    }

    protected void jsClick(By locator) {
        WebElement el = WaitUtils.waitForVisible(locator);
        log.debug("JS-CLICK {}", locator);
        ((JavascriptExecutor) driver()).executeScript("arguments[0].click();", el);
    }

    protected void type(By locator, String text) {
        WebElement el = WaitUtils.waitForVisible(locator);
        el.clear();
        el.sendKeys(text);
        log.debug("TYPE [{}] into {}", maskIfPassword(locator, text), locator);
    }

    protected String getText(By locator) {
        return WaitUtils.waitForVisible(locator).getText().trim();
    }

    protected String getAttr(By locator, String attr) {
        return WaitUtils.waitForVisible(locator).getAttribute(attr);
    }

    protected boolean isDisplayed(By locator) {
        try {
            return WaitUtils.waitForVisible(locator, 5).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    protected boolean isPresent(By locator) {
        return !driver().findElements(locator).isEmpty();
    }

    protected void selectByVisibleText(By locator, String text) {
        new Select(WaitUtils.waitForVisible(locator)).selectByVisibleText(text);
    }

    protected void selectByValue(By locator, String value) {
        new Select(WaitUtils.waitForVisible(locator)).selectByValue(value);
    }

    protected List<WebElement> findAll(By locator) {
        return driver().findElements(locator);
    }

    protected void scrollIntoView(By locator) {
        WebElement el = WaitUtils.waitForVisible(locator);
        ((JavascriptExecutor) driver())
                .executeScript("arguments[0].scrollIntoView({block:'center'});", el);
    }

    public String currentUrl() {
        return driver().getCurrentUrl();
    }

    public String pageTitle() {
        return driver().getTitle();
    }

    private String maskIfPassword(By locator, String text) {
        return locator.toString().toLowerCase().contains("password") ? "******" : text;
    }
}
