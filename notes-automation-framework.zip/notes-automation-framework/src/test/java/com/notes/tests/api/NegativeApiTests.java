package com.notes.tests.api;

import com.notes.api.ApiSpecs;
import com.notes.api.Endpoints;
import com.notes.api.UserApiService;
import com.notes.api.models.NoteDTO;
import com.notes.api.models.UserDTO;
import com.notes.base.BaseAPITest;
import com.notes.utils.ExcelReader;
import com.notes.utils.TestDataFactory;
import io.qameta.allure.*;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Map;

import static io.restassured.RestAssured.given;

/**
 * FR-09 negative scenarios, fully data-driven from
 * TestData.xlsx :: sheet "NegativeApiData".
 *
 * The sheet specifies endpoint, method, whether to attach an auth token,
 * payload fields, and the expected HTTP status. The test dispatches
 * accordingly so adding a new negative case only requires a new row.
 */
@Epic("Notes App")
@Feature("API - Negative scenarios (FR-09)")
public class NegativeApiTests extends BaseAPITest {

    private final UserApiService userApi = new UserApiService();
    private String tokenCache;

    @DataProvider(name = "negativeApiData")
    public Object[][] negativeApiData() {
        return ExcelReader.asDataProvider("NegativeApiData");
    }

    @Test(dataProvider = "negativeApiData",
            description = "FR-09 - Data-driven negative API scenarios",
            groups = {"api", "regression", "negative"})
    @Severity(SeverityLevel.CRITICAL)
    public void negativeApi_dataDriven(Map<String, String> row) {
        String tcid       = row.get("TCID");
        String endpoint   = row.get("Endpoint");
        String method     = row.get("Method").toUpperCase();
        boolean useAuth   = Boolean.parseBoolean(row.get("UseAuthToken"));
        String category   = row.get("Category");
        String title      = row.get("Title");
        String desc       = row.get("NoteDescription");
        int expectedCode  = Integer.parseInt(row.get("ExpectedStatus"));

        Allure.parameter("TCID", tcid);
        Allure.parameter("Description", row.get("Description"));

        Response response;

        if ("/users/login".equals(endpoint) && "POST".equals(method)) {
            // Login-with-wrong-password row: register a valid user first,
            // then try to log in with the bad password from the sheet.
            UserDTO u = new UserDTO(
                    TestDataFactory.uniqueUserName(),
                    TestDataFactory.uniqueEmail(),
                    TestDataFactory.uniquePassword());
            userApi.register(u).then().statusCode(201);
            response = userApi.login(new UserDTO(u.getEmail(), desc /* wrong pwd field */));
        } else {
            // Generic dispatcher for /notes scenarios
            var spec = useAuth ? ApiSpecs.authed(getToken()) : ApiSpecs.request();

            switch (method) {
                case "GET" -> response = given().spec(spec).when().get(endpoint);
                case "POST" -> {
                    NoteDTO body = new NoteDTO(category, title, desc);
                    response = given().spec(spec).body(body).when().post(endpoint);
                }
                case "DELETE" -> response = given().spec(spec).when().delete(endpoint);
                default -> throw new IllegalArgumentException("Unsupported method: " + method);
            }
        }

        Assert.assertEquals(response.statusCode(), expectedCode,
                "[" + tcid + "] Unexpected status. Body=" + response.asString());
    }

    /** Lazy-init a token for rows that need authentication. */
    private synchronized String getToken() {
        if (tokenCache == null) {
            UserDTO u = new UserDTO(
                    TestDataFactory.uniqueUserName(),
                    TestDataFactory.uniqueEmail(),
                    TestDataFactory.uniquePassword());
            userApi.register(u).then().statusCode(201);
            tokenCache = userApi.loginAndGetToken(u.getEmail(), u.getPassword());
        }
        return tokenCache;
    }
}
