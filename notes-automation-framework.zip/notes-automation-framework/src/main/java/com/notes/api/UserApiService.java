package com.notes.api;

import com.notes.api.models.UserDTO;
import io.qameta.allure.Step;
import io.restassured.response.Response;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static io.restassured.RestAssured.given;

public class UserApiService {

    private static final Logger log = LogManager.getLogger(UserApiService.class);

    @Step("API: Register user [{user.email}]")
    public Response register(UserDTO user) {
        log.info("POST {} | email={}", Endpoints.USER_REGISTER, user.getEmail());
        return given()
                .spec(ApiSpecs.request())
                .body(user)
                .when()
                .post(Endpoints.USER_REGISTER);
    }

    @Step("API: Login [{user.email}]")
    public Response login(UserDTO user) {
        log.info("POST {} | email={}", Endpoints.USER_LOGIN, user.getEmail());
        return given()
                .spec(ApiSpecs.request())
                .body(user)
                .when()
                .post(Endpoints.USER_LOGIN);
    }

    /** Convenience: returns the auth token directly (jsonPath: data.token). */
    public String loginAndGetToken(String email, String password) {
        Response r = login(new UserDTO(email, password));
        if (r.statusCode() != 200) {
            throw new RuntimeException(
                    "Login failed: " + r.statusCode() + " body=" + r.asString());
        }
        return r.jsonPath().getString("data.token");
    }

    @Step("API: Get profile")
    public Response getProfile(String token) {
        return given().spec(ApiSpecs.authed(token))
                .when().get(Endpoints.USER_PROFILE);
    }

    @Step("API: Delete account")
    public Response deleteAccount(String token) {
        return given().spec(ApiSpecs.authed(token))
                .when().delete(Endpoints.USER_DELETE);
    }

    @Step("API: Logout")
    public Response logout(String token) {
        return given().spec(ApiSpecs.authed(token))
                .when().delete(Endpoints.USER_LOGOUT);
    }
}
