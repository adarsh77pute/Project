package com.notes.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.function.Supplier;

/** Lightweight retry helper for flaky steps (network, slow DOM, etc.). */
public final class RetryUtils {

    private static final Logger log = LogManager.getLogger(RetryUtils.class);

    private RetryUtils() {}

    public static <T> T withRetry(Supplier<T> action, int maxAttempts, long delayMs, String label) {
        Throwable last = null;
        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            try { return action.get(); }
            catch (Throwable t) {
                last = t;
                log.warn("[{}] attempt {}/{} failed: {}", label, attempt, maxAttempts, t.getMessage());
                if (attempt < maxAttempts) {
                    try { Thread.sleep(delayMs); } catch (InterruptedException ignored) {
                        Thread.currentThread().interrupt();
                    }
                }
            }
        }
        throw new RuntimeException("[" + label + "] failed after " + maxAttempts + " attempts", last);
    }
}
