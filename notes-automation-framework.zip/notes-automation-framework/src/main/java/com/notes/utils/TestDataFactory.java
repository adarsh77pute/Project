package com.notes.utils;

import java.util.UUID;

/**
 * Generates unique test data so parallel test threads never collide.
 * Backed by UUIDs + thread name + timestamp.
 */
public final class TestDataFactory {

    private TestDataFactory() {}

    public static String uniqueEmail() {
        return "qa_" + shortId() + "@autotest.io";
    }

    public static String uniqueUserName() {
        return "QA-User-" + shortId();
    }

    public static String uniquePassword() {
        // Meets common policy: upper + lower + digit + special, >=8 chars
        return "Test@" + shortId() + "1";
    }

    public static String uniqueNoteTitle() {
        return "Note-" + shortId();
    }

    public static String uniqueNoteDescription() {
        return "Auto-generated description " + UUID.randomUUID();
    }

    public static String shortId() {
        return UUID.randomUUID().toString().substring(0, 8);
    }
}
