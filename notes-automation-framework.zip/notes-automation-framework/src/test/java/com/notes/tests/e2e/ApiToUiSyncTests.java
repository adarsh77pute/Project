package com.notes.tests.e2e;

import com.notes.api.NotesApiService;
import com.notes.api.UserApiService;
import com.notes.api.models.NoteDTO;
import com.notes.api.models.UserDTO;
import com.notes.base.BaseUITest;
import com.notes.config.ConfigReader;
import com.notes.pages.LoginPage;
import com.notes.pages.NotesPage;
import com.notes.utils.TestDataFactory;
import io.qameta.allure.*;
import io.restassured.RestAssured;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Hybrid E2E — TC-E2E-02 / FR-07.
 * Note deleted via API must no longer appear in the UI dashboard.
 */
@Epic("Notes App")
@Feature("Hybrid E2E - API → UI sync")
public class ApiToUiSyncTests extends BaseUITest {

    private final UserApiService userApi   = new UserApiService();
    private final NotesApiService notesApi = new NotesApiService();

    @BeforeClass
    public void initApi() {
        RestAssured.baseURI = ConfigReader.get("api.base.url");
    }

    @Test(description = "TC-E2E-02 / FR-07: Note deleted via API must disappear from UI",
            groups = {"e2e", "regression"})
    @Story("API-driven delete reflects in UI")
    @Severity(SeverityLevel.CRITICAL)
    public void apiDeletedNoteVanishesFromUi_FR07() {
        // -------- Setup: register + create note via API --------
        UserDTO user = new UserDTO(
                TestDataFactory.uniqueUserName(),
                TestDataFactory.uniqueEmail(),
                TestDataFactory.uniquePassword());
        userApi.register(user).then().statusCode(201);
        String token = userApi.loginAndGetToken(user.getEmail(), user.getPassword());

        String title = TestDataFactory.uniqueNoteTitle();
        NoteDTO note = new NoteDTO("Work", title, TestDataFactory.uniqueNoteDescription());
        String noteId = notesApi.createAndGetId(token, note);

        // -------- Step 1: Verify the note is visible in UI --------
        NotesPage notes = new LoginPage().loginAs(user.getEmail(), user.getPassword());
        Assert.assertTrue(notes.isNoteVisible(title),
                "Pre-condition: note created via API should appear in UI.");

        // -------- Step 2: Delete via API --------
        notesApi.deleteNote(token, noteId).then().statusCode(200);

        // -------- Step 3: Refresh UI and verify it is gone --------
        driver().navigate().refresh();
        notes = new NotesPage();   // re-bind, dashboard re-renders
        Assert.assertFalse(notes.isNoteVisible(title),
                "Note should no longer appear in UI after API delete.");
    }
}
