package com.notes.utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

public final class JsonUtils {

    private static final ObjectMapper MAPPER = new ObjectMapper()
            .enable(SerializationFeature.INDENT_OUTPUT);

    private JsonUtils() {}

    public static <T> T fromString(String json, Class<T> type) throws IOException {
        return MAPPER.readValue(json, type);
    }

    public static <T> T fromResource(String classpathResource, Class<T> type) throws IOException {
        try (InputStream in = JsonUtils.class.getClassLoader().getResourceAsStream(classpathResource)) {
            if (in == null) throw new IOException("Resource not found: " + classpathResource);
            return MAPPER.readValue(in, type);
        }
    }

    public static JsonNode tree(String json) throws IOException {
        return MAPPER.readTree(json);
    }

    public static String toJson(Object obj) throws IOException {
        return MAPPER.writeValueAsString(obj);
    }

    public static String toPretty(Object obj) throws IOException {
        return MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(obj);
    }

    public static ObjectMapper mapper() {
        return MAPPER;
    }
}
