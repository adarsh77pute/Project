package com.notes.tests.ui;

import com.notes.api.UserApiService;
import com.notes.api.models.UserDTO;
import com.notes.base.BaseUITest;
import com.notes.pages.LoginPage;
import com.notes.pages.NotesPage;
import com.notes.utils.TestDataFactory;
import io.qameta.allure.*;
import org.testng.Assert;
import org.testng.annotations.Test;

@Epic("Notes App")
@Feature("UI - Notes CRUD")
public class NoteCreationTests extends BaseUITest {

    private final UserApiService userApi = new UserApiService();

    @Test(description = "TS-03 / FR-02: User can create a note via UI",
            groups = {"smoke", "ui", "regression"})
    @Story("Create note via UI")
    @Severity(SeverityLevel.BLOCKER)
    public void userCanCreateNoteViaUi_FR02() {
        var user = registerFreshUser();
        NotesPage notes = new LoginPage().loginAs(user.getEmail(), user.getPassword());

        String title = TestDataFactory.uniqueNoteTitle();
        String desc  = TestDataFactory.uniqueNoteDescription();
        notes.createNote("Home", title, desc);

        Assert.assertTrue(notes.isNoteVisible(title),
                "Newly created note should be in the dashboard list.");
    }

    @Test(description = "TS-04 / FR-03: Newly created note shows instantly without refresh",
            groups = {"ui", "regression"})
    @Story("Instant visibility after creation")
    @Severity(SeverityLevel.CRITICAL)
    public void noteAppearsInstantly_FR03() {
        var user = registerFreshUser();
        NotesPage notes = new LoginPage().loginAs(user.getEmail(), user.getPassword());

        int before = notes.countVisibleNotes();
        String title = TestDataFactory.uniqueNoteTitle();
        notes.createNote("Work", title, TestDataFactory.uniqueNoteDescription());
        int after = notes.countVisibleNotes();

        Assert.assertEquals(after, before + 1,
                "Note count should increase by 1 without page refresh.");
        Assert.assertTrue(notes.isNoteVisible(title), "New note should be visible.");
    }

    /** Helper — creates a fresh user via the API so each test is independent. */
    private UserDTO registerFreshUser() {
        UserDTO u = new UserDTO(
                TestDataFactory.uniqueUserName(),
                TestDataFactory.uniqueEmail(),
                TestDataFactory.uniquePassword());
        userApi.register(u).then().statusCode(201);
        return u;
    }
}
