package com.notes.tests.e2e;

import com.notes.api.NotesApiService;
import com.notes.api.UserApiService;
import com.notes.api.models.NoteDTO;
import com.notes.api.models.UserDTO;
import com.notes.base.BaseUITest;
import com.notes.config.ConfigReader;
import com.notes.pages.LoginPage;
import com.notes.pages.NotesPage;
import com.notes.utils.ExcelReader;
import com.notes.utils.TestDataFactory;
import io.qameta.allure.*;
import io.restassured.RestAssured;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;

/**
 * TC-E2E-02 / FR-07: A note deleted via API must no longer appear in UI.
 * Data: TestData.xlsx :: E2EData :: rows where TCID = TC-E2E-02.
 */
@Epic("Notes App")
@Feature("Hybrid E2E - API -> UI sync")
public class ApiToUiSyncTests extends BaseUITest {

    private final UserApiService userApi   = new UserApiService();
    private final NotesApiService notesApi = new NotesApiService();

    @BeforeClass
    public void initApi() {
        RestAssured.baseURI = ConfigReader.get("api.base.url");
    }

    @DataProvider(name = "apiToUiData")
    public Object[][] apiToUiData() {
        List<Map<String, String>> all = ExcelReader.readSheet("E2EData");
        return all.stream()
                .filter(r -> "TC-E2E-02".equals(r.get("TCID")))
                .map(r -> new Object[]{r})
                .toArray(Object[][]::new);
    }

    @Test(dataProvider = "apiToUiData",
            description = "TC-E2E-02 / FR-07 - Note deleted via API disappears from UI",
            groups = {"e2e", "regression"})
    @Story("API delete reflects in UI")
    @Severity(SeverityLevel.CRITICAL)
    public void apiDeletedNoteVanishesFromUi_FR07(Map<String, String> row) {
        String tcid     = row.get("TCID");
        String category = row.get("Category");
        String title    = row.get("Title");
        String desc     = row.get("NoteDescription");

        Allure.parameter("TCID", tcid);
        Allure.parameter("Description", row.get("Description"));

        // --- Setup: register user, create note via API ---
        UserDTO user = new UserDTO(
                TestDataFactory.uniqueUserName(),
                TestDataFactory.uniqueEmail(),
                TestDataFactory.uniquePassword());
        userApi.register(user).then().statusCode(201);
        String token = userApi.loginAndGetToken(user.getEmail(), user.getPassword());

        String noteId = notesApi.createAndGetId(token, new NoteDTO(category, title, desc));

        // --- 1. Verify note is visible in UI ---
        NotesPage notes = new LoginPage().loginAs(user.getEmail(), user.getPassword());
        Assert.assertTrue(notes.isNoteVisible(title),
                "[" + tcid + "] Pre-condition: note created via API should appear in UI.");

        // --- 2. Delete via API ---
        notesApi.deleteNote(token, noteId).then().statusCode(200);

        // --- 3. Refresh UI and verify it is gone ---
        driver().navigate().refresh();
        notes = new NotesPage();
        Assert.assertFalse(notes.isNoteVisible(title),
                "[" + tcid + "] Note should not appear in UI after API delete.");
    }
}
