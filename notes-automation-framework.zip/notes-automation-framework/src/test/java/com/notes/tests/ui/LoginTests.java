package com.notes.tests.ui;

import com.notes.api.UserApiService;
import com.notes.api.models.UserDTO;
import com.notes.base.BaseUITest;
import com.notes.pages.LoginPage;
import com.notes.pages.NotesPage;
import com.notes.utils.ExcelReader;
import io.qameta.allure.*;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Map;

/**
 * UI login tests. Every test case is read from
 * src/test/resources/testdata/TestData.xlsx :: sheet "LoginData".
 * Each Excel row drives one parameterised test invocation.
 */
@Epic("Notes App")
@Feature("UI - Login")
public class LoginTests extends BaseUITest {

    private final UserApiService userApi = new UserApiService();

    @DataProvider(name = "loginData")
    public Object[][] loginData() {
        return ExcelReader.asDataProvider("LoginData");
    }

    @Test(dataProvider = "loginData",
            description = "FR-01 / FR-09 - Data-driven UI login",
            groups = {"smoke", "ui", "regression"})
    @Story("Data-driven login")
    @Severity(SeverityLevel.BLOCKER)
    public void uiLogin_dataDriven(Map<String, String> row) {
        String tcid     = row.get("TCID");
        String email    = row.get("Email");
        String password = row.get("Password");
        boolean registerFirst = Boolean.parseBoolean(row.get("RegisterFirst"));
        String expected = row.get("ExpectedResult");

        Allure.parameter("TCID", tcid);
        Allure.parameter("Description", row.get("Description"));

        // If the row requires a real account, create it via the API fixture
        if (registerFirst) {
            userApi.register(new UserDTO("QA-" + tcid, email, password))
                    .then().statusCode(201);
        }

        LoginPage login = new LoginPage();

        if ("PASS".equalsIgnoreCase(expected)) {
            NotesPage notes = login.loginAs(email, password);
            Assert.assertTrue(notes.isOnDashboard(),
                    "[" + tcid + "] Dashboard should be visible after valid login.");
        } else {
            LoginPage afterAttempt = login.loginExpectingFailure(email, password);
            Assert.assertTrue(afterAttempt.isOnLoginPage(),
                    "[" + tcid + "] Should stay on login page after invalid attempt.");
            Assert.assertFalse(afterAttempt.getErrorMessage().isBlank(),
                    "[" + tcid + "] An error message should be displayed.");
        }
    }
}
