package com.notes.drivers;

import com.notes.config.ConfigReader;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

import java.time.Duration;

/**
 * Thread-safe WebDriver factory.
 * Each TestNG thread gets its own driver via ThreadLocal so parallel="methods" is safe.
 */
public final class DriverFactory {

    private static final Logger log = LogManager.getLogger(DriverFactory.class);
    private static final ThreadLocal<WebDriver> DRIVER = new ThreadLocal<>();

    private DriverFactory() {}

    public static WebDriver getDriver() {
        WebDriver d = DRIVER.get();
        if (d == null) {
            throw new IllegalStateException(
                    "Driver not initialised on thread " + Thread.currentThread().getName());
        }
        return d;
    }

    public static boolean hasDriver() {
        return DRIVER.get() != null;
    }

    public static void initDriver() {
        if (DRIVER.get() != null) return;
        String browser = ConfigReader.get("browser", "chrome").toLowerCase();
        boolean headless = ConfigReader.getBoolean("headless", false);
        WebDriver driver = create(browser, headless);

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(
                Duration.ofSeconds(ConfigReader.getInt("implicit.wait.seconds", 0)));
        driver.manage().timeouts().pageLoadTimeout(
                Duration.ofSeconds(ConfigReader.getInt("page.load.timeout.seconds", 30)));

        DRIVER.set(driver);
        log.info("Driver [{}] initialised on thread [{}] | headless={}",
                browser, Thread.currentThread().getName(), headless);
    }

    public static void quitDriver() {
        WebDriver d = DRIVER.get();
        if (d != null) {
            try { d.quit(); } catch (Exception e) { log.warn("quit threw: {}", e.getMessage()); }
            finally {
                DRIVER.remove();
                log.info("Driver quit on thread [{}]", Thread.currentThread().getName());
            }
        }
    }

    private static WebDriver create(String browser, boolean headless) {
        return switch (browser) {
            case "firefox" -> {
                WebDriverManager.firefoxdriver().setup();
                FirefoxOptions ff = new FirefoxOptions();
                if (headless) ff.addArguments("-headless");
                yield new FirefoxDriver(ff);
            }
            case "edge" -> {
                WebDriverManager.edgedriver().setup();
                EdgeOptions edge = new EdgeOptions();
                if (headless) edge.addArguments("--headless=new");
                yield new EdgeDriver(edge);
            }
            case "chrome" -> {
                WebDriverManager.chromedriver().setup();
                ChromeOptions c = new ChromeOptions();
                c.addArguments("--remote-allow-origins=*");
                c.addArguments("--disable-notifications", "--disable-popup-blocking",
                        "--no-sandbox", "--disable-dev-shm-usage");
                if (headless) {
                    c.addArguments("--headless=new", "--window-size=1920,1080");
                }
                yield new ChromeDriver(c);
            }
            default -> throw new IllegalArgumentException("Unsupported browser: " + browser);
        };
    }
}
