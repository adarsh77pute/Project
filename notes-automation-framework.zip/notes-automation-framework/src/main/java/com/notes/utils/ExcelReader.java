package com.notes.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Apache POI wrapper for reading the TestData.xlsx workbook.
 *
 * Returns each sheet as a List of Maps (header -> value) so test classes
 * can fetch fields by column name instead of by index.
 *
 * Supports the special "AUTO_GEN" token: cells containing that exact string
 * are replaced with unique runtime values from TestDataFactory.
 */
public final class ExcelReader {

    private static final Logger log = LogManager.getLogger(ExcelReader.class);
    private static final String TEST_DATA = "testdata/TestData.xlsx";
    private static final String AUTO_GEN  = "AUTO_GEN";

    private ExcelReader() {}

    /** Read a sheet as a list of header-keyed row maps. */
    public static List<Map<String, String>> readSheet(String sheetName) {
        return readSheet(TEST_DATA, sheetName);
    }

    public static List<Map<String, String>> readSheet(String classpathFile, String sheetName) {
        List<Map<String, String>> rows = new ArrayList<>();
        try (InputStream in = ExcelReader.class.getClassLoader().getResourceAsStream(classpathFile);
             Workbook wb = new XSSFWorkbook(in)) {

            if (in == null) throw new RuntimeException("Excel file not found on classpath: " + classpathFile);
            Sheet sheet = wb.getSheet(sheetName);
            if (sheet == null) throw new RuntimeException("Sheet not found: " + sheetName);

            Row headerRow = sheet.getRow(0);
            if (headerRow == null) throw new RuntimeException("Empty header in sheet: " + sheetName);

            int colCount = headerRow.getLastCellNum();
            List<String> headers = new ArrayList<>();
            for (int c = 0; c < colCount; c++) {
                headers.add(cellToString(headerRow.getCell(c)));
            }

            for (int r = 1; r <= sheet.getLastRowNum(); r++) {
                Row row = sheet.getRow(r);
                if (row == null || isBlankRow(row, colCount)) continue;

                Map<String, String> rowMap = new LinkedHashMap<>();
                for (int c = 0; c < colCount; c++) {
                    String raw = cellToString(row.getCell(c));
                    rowMap.put(headers.get(c), resolveAutoGen(raw, headers.get(c)));
                }
                rows.add(rowMap);
            }
            log.info("Excel [{}] -> {} rows", sheetName, rows.size());
            return rows;
        } catch (Exception e) {
            throw new RuntimeException("Failed to read " + sheetName + " from " + classpathFile, e);
        }
    }

    /** Convert a list of row-maps to a TestNG-friendly Object[][] of single Map params. */
    public static Object[][] asDataProvider(String sheetName) {
        List<Map<String, String>> rows = readSheet(sheetName);
        Object[][] data = new Object[rows.size()][1];
        for (int i = 0; i < rows.size(); i++) {
            data[i][0] = rows.get(i);
        }
        return data;
    }

    // ----------- helpers -----------

    private static String resolveAutoGen(String value, String header) {
        if (!AUTO_GEN.equals(value)) return value;
        String h = header.toLowerCase();
        if (h.contains("email"))    return TestDataFactory.uniqueEmail();
        if (h.contains("password")) return TestDataFactory.uniquePassword();
        if (h.contains("name") && !h.contains("description"))  return TestDataFactory.uniqueUserName();
        if (h.contains("title"))    return TestDataFactory.uniqueNoteTitle();
        if (h.contains("description")) return TestDataFactory.uniqueNoteDescription();
        // Fallback: any unrecognised AUTO_GEN column gets a unique id
        return "auto_" + TestDataFactory.shortId();
    }

    private static String cellToString(Cell cell) {
        if (cell == null) return "";
        return switch (cell.getCellType()) {
            case STRING  -> cell.getStringCellValue().trim();
            case NUMERIC -> DateUtil.isCellDateFormatted(cell)
                    ? cell.getDateCellValue().toString()
                    : trimNumeric(cell.getNumericCellValue());
            case BOOLEAN -> String.valueOf(cell.getBooleanCellValue());
            case FORMULA -> {
                try { yield cell.getStringCellValue().trim(); }
                catch (Exception e) {
                    try { yield trimNumeric(cell.getNumericCellValue()); }
                    catch (Exception ex) { yield ""; }
                }
            }
            default -> "";
        };
    }

    /** Convert 2000.0 -> "2000" but keep 2.5 as "2.5". */
    private static String trimNumeric(double d) {
        if (d == Math.floor(d) && !Double.isInfinite(d)) {
            return String.valueOf((long) d);
        }
        return String.valueOf(d);
    }

    private static boolean isBlankRow(Row row, int colCount) {
        for (int c = 0; c < colCount; c++) {
            if (!cellToString(row.getCell(c)).isEmpty()) return false;
        }
        return true;
    }
}
