package com.notes.pages;

import io.qameta.allure.Step;
import org.openqa.selenium.By;

public class RegisterPage extends BasePage {

    private final By emailInput           = By.id("email");
    private final By nameInput            = By.id("name");
    private final By passwordInput        = By.id("password");
    private final By confirmPasswordInput = By.id("confirmPassword");
    private final By registerButton       = By.cssSelector("button[type='submit']");
    private final By successBanner        = By.cssSelector("[data-testid='alert-message'], .alert-success");

    @Step("Register new user: {email}")
    public LoginPage register(String name, String email, String password) {
        type(nameInput, name);
        type(emailInput, email);
        type(passwordInput, password);
        type(confirmPasswordInput, password);
        click(registerButton);
        return new LoginPage();
    }

    public String getBannerText() { return getText(successBanner); }
}
